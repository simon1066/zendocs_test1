<?php
/**
 * @package admin
 * @copyright Copyright 2003-2018 Zen Cart Development Team
 * @author inspired from sales_report_graphs.php,v 0.01 2002/11/27 19:02:22 cwi Exp  Released under the GNU General Public License $
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Drbyte Thu Jun 7 14:06:01 2018 -0400 New in v1.5.6 $
 */

// adjust and uncomment if a different value is desired
//define('SALES_REPORT_GRAPHS_FILTER_DEFAULT', '00000000110000000000');
