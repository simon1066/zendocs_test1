<?php

require 'vendors/PHPMailer/src/PHPMailer.php';
require 'vendors/PHPMailer/src/Exception.php';
require 'vendors/PHPMailer/src/SMTP.php';
