<?php

namespace Zencart\TableViewControllers;

interface TableViewController
{


}