<?php
/**
 * @package htmleditors
 * @copyright Copyright 2003-2011 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: editors_list.php 18711 2011-05-09 22:57:25Z kuroi $
 */
/*
 * NOTE: This file is deprecated for v1.5.0 onwards and may be deleted.
 */
