<?php
/**
 *
 * @package initSystem
 * @copyright Copyright 2003-2011 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: init_sanitize.php 18698 2011-05-04 14:50:06Z wilt $
 */

// ** NOTE: THIS FILE CAN BE DELETED. It is no longer needed.